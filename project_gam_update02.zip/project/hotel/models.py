from django.db import models

# Create your models here.

class User(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    username = models.CharField(max_length=100, unique=True)
    password = models.CharField(max_length=255)
    role = models.CharField(max_length=50)

    def __str__(self):
        return self.username
    
class RoomTypes(models.Model):
    name = models.CharField(max_length=155)

    def __str__(self):
        return self.name

class Rooms(models.Model):
    name = models.CharField(max_length=155)
    price = models.IntegerField()
    room_types = models.ManyToManyField(RoomTypes, related_name='rooms')

    def __str__(self):
        return self.name
       
class Promotion(models.Model):
    name = models.CharField(max_length=100)
    discount_percent = models.IntegerField()
    description = models.TextField()
    start_date = models.DateTimeField()
    expire_date = models.DateTimeField()

    def __str__(self):
        return self.name
    
class Bookings(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    room = models.ForeignKey(Rooms, on_delete=models.CASCADE)  # เชื่อมกับตาราง Room
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    promotion = models.ForeignKey(Promotion, null=True, blank=True, on_delete=models.SET_NULL)  # เชื่อมกับ Promotion (สามารถเป็นค่าว่างได้)
    total_price = models.DecimalField(max_digits=10, decimal_places=2) 
    payment_status = models.BooleanField()