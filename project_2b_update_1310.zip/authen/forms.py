from django import forms
from hotel.models import *
from django.core.exceptions import ValidationError
from datetime import date, datetime
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

from django.forms import ModelForm, SplitDateTimeField
from django.forms.widgets import Textarea, TextInput, SplitDateTimeWidget

class RegisterForm(UserCreationForm):
    first_name = forms.CharField(
        label="First name", 
        max_length=100, 
        widget = forms.TextInput(attrs={'class': 'form-control text-start w-100'})
        )
    
    last_name = forms.CharField(
        label="Last name", 
        max_length=100, 
        widget = forms.TextInput(attrs={'class': 'form-control'})
        )
    
    username = forms.CharField(
        label="Username", 
        max_length=100, 
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    
    password1 = forms.CharField(
        label="Password",
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )
    
    password2 = forms.CharField(
        label="Confirm Password",
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )
    
    class Meta:
        model = User
        fields = {
            
            'first_name',
            'last_name',
            'username',
            'password1',
            'password2'
        }

        # widgets = {
        #     'username': forms.widgets.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your username'}),
        #     'password1': forms.widgets.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter your password'}),
        #     'password2': forms.widgets.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter your confirm password'}),
            
        # }
