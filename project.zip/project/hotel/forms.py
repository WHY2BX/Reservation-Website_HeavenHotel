from django import forms
from .models import *
from django.forms import ModelForm, SplitDateTimeField
from django.forms.widgets import Textarea, TextInput, SplitDateTimeWidget
from django.core.exceptions import ValidationError
from datetime import datetime

from django.forms import ModelForm

class NewBookingForm(ModelForm):
    promotion = forms.ModelChoiceField(queryset=Promotion.objects.all())

    class Meta:
        model = Bookings
        fields = [
            "start_date", 
            "end_date", 
            "promotion", 
        ]
        widgets = {
            'start_date': forms.widgets.DateInput(attrs={'type': 'date'}),
            'end_date': forms.widgets.DateInput(attrs={'type': 'date'})
        }

    #validated
    def clean_hire_date(self):
        start_date = self.cleaned_data.get("start_date")
        end_date = self.cleaned_data.get("end_date")
        now = datetime.now().date()

        if start_date and now and now > start_date:
            self.add_error(
                'start_date',
                "จองห้องให้ใครในอดีตเหรอจ๊ะ"
            )

        return start_date
    
class EditBookingForm(ModelForm):
    room = forms.ModelChoiceField(queryset=Rooms.objects.all())
    promotion = forms.ModelChoiceField(queryset=Promotion.objects.all())

    class Meta:
        model = Bookings
        fields = [
            'room',
            "start_date", 
            "end_date", 
            "promotion", 
        ]
        widgets = {
            'start_date': forms.widgets.DateInput(attrs={'type': 'date'}),
            'end_date': forms.widgets.DateInput(attrs={'type': 'date'})
        }

    #validated
    def clean_hire_date(self):
        start_date = self.cleaned_data.get("start_date")
        end_date = self.cleaned_data.get("end_date")
        now = datetime.now().date()

        if start_date and now and now > start_date:
            self.add_error(
                'start_date',
                "จองห้องให้ใครในอดีตเหรอจ๊ะ"
            )

        return start_date