from django.shortcuts import render
from .models import *
from django.db.models import Count
from django.http import JsonResponse

# Create your views here.

def mainpage(request):
    room = Rooms.objects.all()
    context = {
        "room" : room
    }

    return render(request, "mainpage.html", context)