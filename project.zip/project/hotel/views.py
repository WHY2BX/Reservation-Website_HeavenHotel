from django.shortcuts import render, redirect
from .models import *
from django.db.models import Count
from django.http import JsonResponse
from .forms import *

# Create your views here.

def mainpage(request):
    room = Rooms.objects.all()
    context = {
        "room" : room
    }

    return render(request, "mainpage.html", context)

def managePromotion(request):
    promotion = Promotion.objects.all()
    context = {
        "promotion" : promotion
    }

    return render(request, "managepro.html", context)

def createRoom(request):
    if request.method == "POST":
        form = createRoomForm(request.POST)

        if form.is_valid():
            print(form.cleaned_data)
            new_room = Rooms.objects.create(
                name = form.cleaned_data['name'],
                price = form.cleaned_data['price'],
            )
            # room_type เป็น many-to-many เพิ่มไปพร้อมกันเลยไม่ได้ ต้องเอามาเพิ่มแยก
            new_room.room_types.set(form.cleaned_data['types'])
        
            return redirect("mainpage")
        
    else:
        form = createRoomForm()

    return render(request, "createroom.html", {"form": form})

def createPromotion(request):
    if request.method == "POST":
        form = createPromotionForm(request.POST)

        if form.is_valid():
            print(form.cleaned_data)
            new_promotion = Promotion.objects.create(
                name = form.cleaned_data['name'],
                discount_percent = form.cleaned_data['discount_percent'],
                description = form.cleaned_data['description'],
                start_date = form.cleaned_data['start_date'],
                expire_date = form.cleaned_data['expire_date'],
            )
        
            return redirect("mainpage")
        
    else:
        form = createPromotionForm()

    return render(request, "createpro.html", {"form": form})