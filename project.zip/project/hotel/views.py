from django.shortcuts import render, redirect
from django.views import View
from .models import *
from django.db.models import *
from django.http import JsonResponse, HttpResponse
from .forms import *
from django.db import transaction
from django.http import HttpRequest
from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404


# Create your views here.

def mainpage(request):
    room = Rooms.objects.all()
    context = {
        "room" : room
    }

    return render(request, "mainpage.html", context)


# add duay
class BookingView(View):
    def post(self, request, room_id):
        form = NewBookingForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data)
            Bookings.objects.create(
                user = User.objects.get(pk=1), 
                room = Rooms.objects.get(pk=room_id),
                start_date = form.cleaned_data['start_date'],
                end_date = form.cleaned_data['end_date'],
                promotion = form.cleaned_data['promotion'],
                total_price = Rooms.objects.get(pk=room_id).price,
                payment_status = False
                )
            return redirect('mainpage')
    def get(self, request, room_id):
        form = NewBookingForm()
        room = Rooms.objects.get(pk=room_id)
        context = {
            "NewBookingForm": form,
            'room' : room
            }
        return render(request, "booking_form.html", context)
    
class EditBookingView(View):
    
    def post(self, request: HttpRequest, booking_id):
        booking = get_object_or_404(Bookings, pk=booking_id)
        
        form = EditBookingForm(request.POST, instance=booking)
        
        if form.is_valid():
            form.save()  
            return redirect('mainpage')
        else:
            context = {
            "booking": booking,
            "form": form  
        }
        return render(request, "edit_bookings.html", context)

    def get(self, request, booking_id):
        booking = get_object_or_404(Bookings, pk=booking_id)
        form = EditBookingForm(instance=booking)
        context = {
            "booking": booking,
            "form": form  
        }
        return render(request, "edit_bookings.html", context)