from django.urls import path

from . import views

urlpatterns = [
    path("", views.mainpage, name="mainpage"),

    # add to gam file duay
    path("booking/<int:room_id>/", views.BookingView.as_view(), name="booking"),
    path("edit-booking/<int:booking_id>/", views.EditBookingView.as_view(), name="editBooking"),
]