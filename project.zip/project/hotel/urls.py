from django.urls import path

from . import views

urlpatterns = [
    path("", views.mainpage, name="mainpage"),
    path("managepro/", views.managePromotion, name="managePromotion"),
    path("createroom/", views.createRoom, name="createRoom"),
    path("createpromotion/", views.createPromotion, name="createPromotion"),
    
   
]