from django.urls import path

from . import views

urlpatterns = [
    path("", views.mainpage, name="mainpage"),

    path("manageroom/", views.manageRoom, name="manageRoom"),
    path("manageroom/deleteroom/<int:room_id>/", views.deleteRoom, name="deleteRoom"),
    
    path("managepro/", views.managePromotion, name="managePromotion"),
    path("managepro/deletepro/<int:promotion_id>/", views.deletePromotion, name="deletePromotion"),

    # Create
    path("createroom/", views.createRoom, name="createRoom"),
    path("createpromotion/", views.createPromotion, name="createPromotion"),

]