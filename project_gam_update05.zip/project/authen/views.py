from django.shortcuts import render, redirect
from django.contrib.auth import logout, login, authenticate
from django.contrib import messages
from django.views import View
from .forms import RegisterForm

from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import UserCreationForm

class LoginView(View):
    def get(self, request):
        form = AuthenticationForm()
        return render(request, 'login.html', {"form": form})
    
    def post(self, request):
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user() 
            login(request,user)

            if request.user.is_staff:
                return redirect('bookingList')
            else:
                return redirect('mainpage')
        return render(request,'login.html', {"form":form})


class LogoutView(View):
    def get(self, request):
        logout(request) #clear session
        return render(request,'homepage.html')
    
 
class RegisterView(View):
    def get(self, request):
        form = RegisterForm()  
        context = {  
            'form':form  
        }  
        return render(request, 'register.html', context)
    
    def post(self, request):
        form = RegisterForm(request.POST)
        # ตรวจว่ากรอกมาถูกไหม
        if form.is_valid():  
            form.save() 
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
    
            # ตรวจว่ามี username, password ใน DB ไหม
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                messages.success(request, 'Account created successfully')
                return redirect('register')
        else:
            messages.error(request, 'There was a problem with your registration.')
            return render(request, 'register.html', {'form': form})

          
